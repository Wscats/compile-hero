<?php
$getInput = $_GET["input"];
//	if($getInput=="姚老师"){
//		echo $getInput."你好傻啊";
//	}else{
//		echo $getInput."你好聪明噢";
//	}
//sql
$getInput++;
echo $getInput . "你好聪明噢";
?>